
package net.mcreator.modificationpart.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.modificationpart.entity.ZombieHardEntity;
import net.mcreator.modificationpart.client.model.ModelzombieHard;

public class ZombieHardRenderer extends MobRenderer<ZombieHardEntity, ModelzombieHard<ZombieHardEntity>> {
	public ZombieHardRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelzombieHard(context.bakeLayer(ModelzombieHard.LAYER_LOCATION)), 1f);
		this.addLayer(new EyesLayer<ZombieHardEntity, ModelzombieHard<ZombieHardEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("modificationpart:textures/entities/eyesforhardzombie.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(ZombieHardEntity entity) {
		return new ResourceLocation("modificationpart:textures/entities/zombiehard.png");
	}
}
