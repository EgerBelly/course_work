
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modificationpart.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.modificationpart.client.renderer.ZombieMiddleRenderer;
import net.mcreator.modificationpart.client.renderer.ZombieMiddleNotLightingEyesRenderer;
import net.mcreator.modificationpart.client.renderer.ZombieHardRenderer;
import net.mcreator.modificationpart.client.renderer.ZombieHardNotLightingEyesRenderer;
import net.mcreator.modificationpart.client.renderer.ZombieEasyRenderer;
import net.mcreator.modificationpart.client.renderer.ZombieEasyNotLightEyesRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModificationpartModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ModificationpartModEntities.ZOMBIE_MIDDLE_NOT_LIGHTING_EYES.get(), ZombieMiddleNotLightingEyesRenderer::new);
		event.registerEntityRenderer(ModificationpartModEntities.ZOMBIE_EASY_NOT_LIGHT_EYES.get(), ZombieEasyNotLightEyesRenderer::new);
		event.registerEntityRenderer(ModificationpartModEntities.ZOMBIE_HARD_NOT_LIGHTING_EYES.get(), ZombieHardNotLightingEyesRenderer::new);
		event.registerEntityRenderer(ModificationpartModEntities.ZOMBIE_EASY.get(), ZombieEasyRenderer::new);
		event.registerEntityRenderer(ModificationpartModEntities.ZOMBIE_MIDDLE.get(), ZombieMiddleRenderer::new);
		event.registerEntityRenderer(ModificationpartModEntities.ZOMBIE_HARD.get(), ZombieHardRenderer::new);
	}
}
