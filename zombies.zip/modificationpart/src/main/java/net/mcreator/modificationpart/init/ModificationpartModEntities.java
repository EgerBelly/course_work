
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modificationpart.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.modificationpart.entity.ZombieMiddleNotLightingEyesEntity;
import net.mcreator.modificationpart.entity.ZombieMiddleEntity;
import net.mcreator.modificationpart.entity.ZombieHardNotLightingEyesEntity;
import net.mcreator.modificationpart.entity.ZombieHardEntity;
import net.mcreator.modificationpart.entity.ZombieEasyNotLightEyesEntity;
import net.mcreator.modificationpart.entity.ZombieEasyEntity;
import net.mcreator.modificationpart.ModificationpartMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModificationpartModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ModificationpartMod.MODID);
	public static final RegistryObject<EntityType<ZombieMiddleNotLightingEyesEntity>> ZOMBIE_MIDDLE_NOT_LIGHTING_EYES = register("zombie_middle_not_lighting_eyes",
			EntityType.Builder.<ZombieMiddleNotLightingEyesEntity>of(ZombieMiddleNotLightingEyesEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(ZombieMiddleNotLightingEyesEntity::new)

					.sized(0.6f, 3f));
	public static final RegistryObject<EntityType<ZombieEasyNotLightEyesEntity>> ZOMBIE_EASY_NOT_LIGHT_EYES = register("zombie_easy_not_light_eyes",
			EntityType.Builder.<ZombieEasyNotLightEyesEntity>of(ZombieEasyNotLightEyesEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(ZombieEasyNotLightEyesEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ZombieHardNotLightingEyesEntity>> ZOMBIE_HARD_NOT_LIGHTING_EYES = register("zombie_hard_not_lighting_eyes",
			EntityType.Builder.<ZombieHardNotLightingEyesEntity>of(ZombieHardNotLightingEyesEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(ZombieHardNotLightingEyesEntity::new)

					.sized(1f, 3f));
	public static final RegistryObject<EntityType<ZombieEasyEntity>> ZOMBIE_EASY = register("zombie_easy",
			EntityType.Builder.<ZombieEasyEntity>of(ZombieEasyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombieEasyEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ZombieMiddleEntity>> ZOMBIE_MIDDLE = register("zombie_middle",
			EntityType.Builder.<ZombieMiddleEntity>of(ZombieMiddleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombieMiddleEntity::new)

					.sized(0.6f, 3f));
	public static final RegistryObject<EntityType<ZombieHardEntity>> ZOMBIE_HARD = register("zombie_hard",
			EntityType.Builder.<ZombieHardEntity>of(ZombieHardEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombieHardEntity::new)

					.sized(1f, 3f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			ZombieMiddleNotLightingEyesEntity.init();
			ZombieEasyNotLightEyesEntity.init();
			ZombieHardNotLightingEyesEntity.init();
			ZombieEasyEntity.init();
			ZombieMiddleEntity.init();
			ZombieHardEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ZOMBIE_MIDDLE_NOT_LIGHTING_EYES.get(), ZombieMiddleNotLightingEyesEntity.createAttributes().build());
		event.put(ZOMBIE_EASY_NOT_LIGHT_EYES.get(), ZombieEasyNotLightEyesEntity.createAttributes().build());
		event.put(ZOMBIE_HARD_NOT_LIGHTING_EYES.get(), ZombieHardNotLightingEyesEntity.createAttributes().build());
		event.put(ZOMBIE_EASY.get(), ZombieEasyEntity.createAttributes().build());
		event.put(ZOMBIE_MIDDLE.get(), ZombieMiddleEntity.createAttributes().build());
		event.put(ZOMBIE_HARD.get(), ZombieHardEntity.createAttributes().build());
	}
}
