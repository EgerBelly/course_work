
package net.mcreator.modificationpart.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.modificationpart.entity.ZombieHardNotLightingEyesEntity;
import net.mcreator.modificationpart.client.model.ModelzombieHard;

public class ZombieHardNotLightingEyesRenderer extends MobRenderer<ZombieHardNotLightingEyesEntity, ModelzombieHard<ZombieHardNotLightingEyesEntity>> {
	public ZombieHardNotLightingEyesRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelzombieHard(context.bakeLayer(ModelzombieHard.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(ZombieHardNotLightingEyesEntity entity) {
		return new ResourceLocation("modificationpart:textures/entities/zombiehard.png");
	}
}
