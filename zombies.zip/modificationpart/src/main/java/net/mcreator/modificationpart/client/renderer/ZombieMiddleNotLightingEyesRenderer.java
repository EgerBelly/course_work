
package net.mcreator.modificationpart.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.modificationpart.entity.ZombieMiddleNotLightingEyesEntity;
import net.mcreator.modificationpart.client.model.ModelzombieMiddle;

public class ZombieMiddleNotLightingEyesRenderer extends MobRenderer<ZombieMiddleNotLightingEyesEntity, ModelzombieMiddle<ZombieMiddleNotLightingEyesEntity>> {
	public ZombieMiddleNotLightingEyesRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelzombieMiddle(context.bakeLayer(ModelzombieMiddle.LAYER_LOCATION)), 0.6f);
	}

	@Override
	public ResourceLocation getTextureLocation(ZombieMiddleNotLightingEyesEntity entity) {
		return new ResourceLocation("modificationpart:textures/entities/zombiemiddle.png");
	}
}
