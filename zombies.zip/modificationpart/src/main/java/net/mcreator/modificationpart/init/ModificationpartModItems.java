
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modificationpart.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

import net.mcreator.modificationpart.ModificationpartMod;

public class ModificationpartModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ModificationpartMod.MODID);
	public static final RegistryObject<Item> ZOMBIE_MIDDLE_NOT_LIGHTING_EYES_SPAWN_EGG = REGISTRY.register("zombie_middle_not_lighting_eyes_spawn_egg",
			() -> new ForgeSpawnEggItem(ModificationpartModEntities.ZOMBIE_MIDDLE_NOT_LIGHTING_EYES, -65536, -3355393, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ZOMBIE_EASY_NOT_LIGHT_EYES_SPAWN_EGG = REGISTRY.register("zombie_easy_not_light_eyes_spawn_egg",
			() -> new ForgeSpawnEggItem(ModificationpartModEntities.ZOMBIE_EASY_NOT_LIGHT_EYES, -65536, -3342388, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ZOMBIE_HARD_NOT_LIGHTING_EYES_SPAWN_EGG = REGISTRY.register("zombie_hard_not_lighting_eyes_spawn_egg",
			() -> new ForgeSpawnEggItem(ModificationpartModEntities.ZOMBIE_HARD_NOT_LIGHTING_EYES, -65536, -10066177, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ZOMBIE_EASY_SPAWN_EGG = REGISTRY.register("zombie_easy_spawn_egg", () -> new ForgeSpawnEggItem(ModificationpartModEntities.ZOMBIE_EASY, -65536, -256, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ZOMBIE_MIDDLE_SPAWN_EGG = REGISTRY.register("zombie_middle_spawn_egg",
			() -> new ForgeSpawnEggItem(ModificationpartModEntities.ZOMBIE_MIDDLE, -65536, -16724788, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ZOMBIE_HARD_SPAWN_EGG = REGISTRY.register("zombie_hard_spawn_egg",
			() -> new ForgeSpawnEggItem(ModificationpartModEntities.ZOMBIE_HARD, -65536, -6750055, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
}
