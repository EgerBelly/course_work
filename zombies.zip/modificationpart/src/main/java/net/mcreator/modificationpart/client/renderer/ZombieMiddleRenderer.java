
package net.mcreator.modificationpart.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.modificationpart.entity.ZombieMiddleEntity;
import net.mcreator.modificationpart.client.model.ModelzombieMiddle;

public class ZombieMiddleRenderer extends MobRenderer<ZombieMiddleEntity, ModelzombieMiddle<ZombieMiddleEntity>> {
	public ZombieMiddleRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelzombieMiddle(context.bakeLayer(ModelzombieMiddle.LAYER_LOCATION)), 0.6f);
		this.addLayer(new EyesLayer<ZombieMiddleEntity, ModelzombieMiddle<ZombieMiddleEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("modificationpart:textures/entities/eyesformiddlezombie.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(ZombieMiddleEntity entity) {
		return new ResourceLocation("modificationpart:textures/entities/zombiemiddle.png");
	}
}
