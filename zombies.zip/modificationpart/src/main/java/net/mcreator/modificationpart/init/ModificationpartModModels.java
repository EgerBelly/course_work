
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modificationpart.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.modificationpart.client.model.ModelzombieMiddle;
import net.mcreator.modificationpart.client.model.ModelzombieHard;
import net.mcreator.modificationpart.client.model.ModelzombieEasy;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class ModificationpartModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelzombieEasy.LAYER_LOCATION, ModelzombieEasy::createBodyLayer);
		event.registerLayerDefinition(ModelzombieMiddle.LAYER_LOCATION, ModelzombieMiddle::createBodyLayer);
		event.registerLayerDefinition(ModelzombieHard.LAYER_LOCATION, ModelzombieHard::createBodyLayer);
	}
}
